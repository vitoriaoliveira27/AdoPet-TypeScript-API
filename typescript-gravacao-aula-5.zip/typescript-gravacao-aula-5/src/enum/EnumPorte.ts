enum EnumPorte {
  pequeno = "pequeno",
  medio = "medio",
  grande = "grande",
}

export default EnumPorte;
