enum EnumEspecie {
  CACHORRO = "cachorro",
  GATO = "gato",
  TARTARUGA = "tartaruga",
}

export default EnumEspecie;
